/*global systemDictionary:true */
"use strict";

systemDictionary = {
    "smaho-c adapter settings": {
        en: "Adapter settings for smaho-c",
        de: "Adaptereinstellungen für smaho-c",
    },
    serialport: {
        en: "serial port",
        de: "Serielle Schnittstelle",
    },
    baudrate: {
        en: "baud rate",
        de: "Baud rate",
    },
};
