import SmaHoConf from "./SmaHoConf";

class SmaHoOutputConf extends SmaHoConf {
    constructor() {
        super();
    }
}

export = SmaHoOutputConf;
