class SmaHoConf {
    public Index: number;
    public Name: string;
    constructor() {
        this.Index = -1;
        this.Name = "";
    }
}

export = SmaHoConf;
