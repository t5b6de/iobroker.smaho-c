import SmaHoPacketizer from "../../SmaHoPacketizer";
import PacketBase from "../PacketBase";
import PacketType from "../PacketType";

class ConfigOutputResponsePacket extends PacketBase {
    private _Index: number;
    private _Outputs: Array<number>;
    private _CbReceived: CallableFunction;

    constructor(packetizer: SmaHoPacketizer, cbReceived: CallableFunction) {
        super(PacketType.ConfigOutputResponse, 2, packetizer);

        this._CbReceived = cbReceived;

        this._Cb = this.cbFun;
        this._Index = 0;
        this._Outputs = [];

        if (this._InitialParsed) {
            this._FullyParsed = this.parsePacket();
        }
    }

    private async cbFun(): Promise<void> {
        this._CbReceived(this);
    }

    private parsePacket(): boolean {
        const count = this._Packetizer.getPacketLen() - 2; // remove cmd + index

        if (count > 15) return false;

        for (let i = 0; i < count; i++) {
            this._Outputs.push(this._Packetizer.getByte(2 + i));
        }

        this._Index = this._Packetizer.getByte(1);

        // no further check needed.
        return true;
    }

    public getIndex(): number {
        return this._Index;
    }

    public getOutputs(): Array<number> {
        return this._Outputs;
    }
}

export = ConfigOutputResponsePacket;
