import SmaHoPacketizer from "../../SmaHoPacketizer";
import PacketBase from "../PacketBase";
import PacketType from "../PacketType";

class ConfigOutputWritePacket extends PacketBase {
    private _Outputs: Array<number>;
    private _Index: number;

    constructor(index: number, outputs: Array<number>) {
        super(PacketType.ConfigOutputWrite, 2, new SmaHoPacketizer()); // nr cmd byte
        this._GenCb = this.genPacketData;
        this._Index = index;
        this._Outputs = outputs;
    }

    private genPacketData(): void {
        if (this._Packetizer.isCompleted()) return;

        let len = 2;
        let b: Buffer = null;

        if (this._Outputs != null && this._Outputs.length > 0) {
            b = Buffer.from(this._Outputs);
            len += this._Outputs.length;
        }

        this._Packetizer.addByte(this._Packetizer.cSyncByte);
        this._Packetizer.addByte(len); // len, cmd + In/Out + number
        this._Packetizer.addByte(this._Command);
        this._Packetizer.addByte(this._Index);

        if (b != null) {
            this._Packetizer.addBuffer(b);
        }
    }
}

export = ConfigOutputWritePacket;
