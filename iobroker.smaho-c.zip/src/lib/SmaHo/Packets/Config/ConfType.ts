enum ConfType {
    Input,
    Output,
    OutputGroup,
    MotionSensor,
}

export = ConfType;
