enum NameType {
    Output = 0x00,
    Input = 0x01,
    OutGroup = 0x02,
    MotionDetection = 0x03,
}

export = NameType;
