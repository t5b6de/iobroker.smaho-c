import SmaHoConf from "./SmaHoConf";

class SmaHoGroupConf extends SmaHoConf {
    public Outputs: Array<number>;

    constructor() {
        super();
        this.Outputs = [];
    }
}

export = SmaHoGroupConf;
